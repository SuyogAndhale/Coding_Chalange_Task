import React, { useState } from 'react';
import '../App.css';

const Tree = ({data = []}) => {
	console.log(data);
	return (
		<div>
			<ul>
				{data.map(tree => (
					<TreeNode node={tree}/>
				))}
			</ul>
		</div>
	)
}

const TreeNode = ({node}) => {
	const [childVisible, setChildVisible] = useState(false);
	const hasChild = node.children ? true : false;

	return (
		<li>
			<span className="caret">{node.label}</span>
			<ul>
				{console.log(node)}
				<li></li>
			</ul>
		</li>
	)
}

export default Tree