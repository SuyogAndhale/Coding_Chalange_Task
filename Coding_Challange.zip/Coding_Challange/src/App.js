import './App.css';
import React, { useState, useEffect } from 'react';
import Tree from './Components/Tree';
import axios from 'axios';

const url = "http://117.217.126.114:8050/api/MenuMasters/GetMenuMasterList/173";

const data = [{
  label: "fruit",
  fruit: ["apple", "mango"],
},
{
  label: "vegetable",
  vegetable: ["salad", "potato"],
}
];

function App() {
  const [treeData, setTreeData] = useState(null);
  console.log(data);
  // useEffect(() => {
  //   // axios.get(url).then((response) => {
  //   //   setTreeData(response.data);
  //   // });
  //   // setTreeData(data);
  // }, []);

  return (
    <div className="App">
      <Tree data={data}/>
    </div>
  );
}

export default App;
